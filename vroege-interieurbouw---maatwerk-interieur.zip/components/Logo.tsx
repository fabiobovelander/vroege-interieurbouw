
import React from 'react';

const Logo: React.FC = () => {
  return (
    <img src="/images/logo-vroege.png" alt="Vroege interieurbouw logo" />
  );
};

export default Logo;
